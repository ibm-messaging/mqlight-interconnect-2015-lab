This ZIP file contains the binaries for the IBM Bluemix MQ Light Service Worker Offload Node.js Sample, which allows you to quickly see the MQ Light Service for Bluemix in action.

To deploy this sample onto Bluemix, 

1. Sign up for Bluemix if you don�t have an account yet (https://ace.ng.bluemix.net/).
2. Install and setup the Cloud Foundry command line interface (https://www.ng.bluemix.net/docs/#cli/index.html), which will allow you to manage your Bluemix applications from your machine (don�t forget to cf login � have a look at https://www.ng.bluemix.net/docs/#starters/BuildingWeb.html#connect_bluemix if you need any help)
3. Unzip this into a new directory and navigate to mqlight-worker-offload-sample-node
4. Create an MQ Light service instance that the app can use when it�s deployed to Bluemix:
   cf cs mqlight standard MQLight-sampleservice
5. Push the apps to Bluemix:
   cf push

If you would like to get more information about the source code, please have a look at this article (https://developer.ibm.com/messaging/?p=1757&preview=true) which explains the contents of this sample in more detail.
